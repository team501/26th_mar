// Agency nav links
export default {
   category1: [
      {
         "menu_title": "sidebar.dashboard",
         "menu_icon": "zmdi zmdi-view-dashboard",
         "child_routes": [
            {
               "path": "/app/dashboard/ecommerce",
               "menu_title": "sidebar.ecommerce",
               exact: true
            },
            {
               "path": "/horizontal/dashboard/saas",
               "menu_title": "sidebar.saas",
               exact: true
            },
            {
               "path": "/agency/dashboard/agency",
               "menu_title": "sidebar.agency",
               exact: true
            },
            {
               "path": "/boxed/dashboard/news",
               "menu_title": "sidebar.news",
               exact: true
            }
         ]
      },
      {
         "menu_title": "sidebar.ecommerce",
         "menu_icon": "zmdi zmdi-shopping-cart",
         "child_routes": [
            {
               "path": "/ecommerce/shop",
               "menu_title": "sidebar.shop"
            },
            {
               "path": "/ecommerce/cart",
               "menu_title": "sidebar.cart"
            },
            {
               "path": "/ecommerce/checkout",
               "menu_title": "sidebar.checkout"
            },
            {
               "path": "/ecommerce/shop-list",
               "menu_title": "sidebar.shopList"
            },
            {
               "path": "/ecommerce/shop-grid",
               "menu_title": "sidebar.shopGrid"
            },
            {
               "path": "/ecommerce/invoice",
               "menu_title": "sidebar.invoice"
            }
         ]
      },
      {
         "menu_title": "sidebar.widgets",
         "menu_icon": "zmdi zmdi-widgets",
         "child_routes": [
            {
               "path": "/widgets/charts",
               "menu_title": "sidebar.charts"
            },
            {
               "path": "/widgets/promo",
               "menu_title": "sidebar.promo"
            },
            {
               "path": "/widgets/general",
               "menu_title": "sidebar.general"
            },
            {
               "path": "/widgets/user",
               "menu_title": "sidebar.user"
            },
         ]
      },
      {
         "menu_title": "sidebar.pages",
         "menu_icon": "zmdi zmdi-file-plus",
         "child_routes": [
            {
               "path": "/pages/gallery",
               "menu_title": "sidebar.gallery"
            },
            {
               "path": "/pages/pricing",
               "menu_title": "sidebar.pricing"
            },
            {
               "path": "/pages/blank",
               "menu_title": "sidebar.blank"
            },
            {
               "path": "/terms-condition",
               "menu_title": "sidebar.terms&Conditions"
            },
            {
               "path": "/pages/feedback",
               "menu_title": "sidebar.feedback"
            },
            {
               "path": "/pages/report",
               "menu_title": "sidebar.report"
            },
            {
               "path": "/pages/faq",
               "menu_title": "sidebar.faq(s)"
            }
         ]
      },
      {
         "menu_title": "sidebar.session",
         "menu_icon": "zmdi zmdi-time",
         "child_routes": [
            {
               "path": "/session/login",
               "menu_title": "sidebar.login",
               exact: true
            },
            {
               "path": "/session/register",
               "menu_title": "sidebar.register",
               exact: true
            },
            {
               "path": "/session/lock-screen",
               "menu_title": "sidebar.lockScreen",
               exact: true
            },
            {
               "path": "/session/forgot-password",
               "menu_title": "sidebar.forgotPassword",
               exact: true
            },
            {
               "path": "/session/404",
               "menu_title": "sidebar.404",
               exact: true
            },
            {
               "path": "/session/500",
               "menu_title": "sidebar.500",
               exact: true
            }
         ]
      }
   ]
}
