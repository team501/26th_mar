import React, { Component } from 'react';
import FooterLogo from '../../assets/img/fortna_innerlogo.png';

	const powered = {
		
	};
	
class Footer extends React.Component {
	
	
    render(){
      return(
        <div>
          <div className="footergap">&nbsp;</div>
            <div className="footer">
              @2018 FORTNA INC. ALL RIGHTS RESERVED.
            <div className="powered">Powerded By &nbsp; <img src={FooterLogo} /></div>
          </div>
        </div>
		  );
    }
  }
export default Footer;
