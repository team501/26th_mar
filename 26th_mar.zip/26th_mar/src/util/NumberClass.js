import React, { Component } from 'react';

class NumberClass extends Component {
	
	render() {
		//Read number format from local storage or else from default config. 
		const numberFormat = localStorage.getItem("lang") != null && localStorage.getItem("lang") != undefined  ? JSON.parse(localStorage.getItem("lang")).numberFormat : AppConfig.locale.numberFormat;
		return (      
					new Intl.NumberFormat(numberFormat, { maximumSignificantDigits: 10 }).format(this.props.number)      
				);
	}
}

const NumberFormatter = (value) => {
	const numberFormat = localStorage.getItem("lang") != null && localStorage.getItem("lang") != undefined  ? JSON.parse(localStorage.getItem("lang")).numberFormat : AppConfig.locale.numberFormat;
	return new Intl.NumberFormat(numberFormat, { maximumSignificantDigits: 10 }).format(value);
};
export default NumberClass;

export {
	NumberFormatter
};